# Pyarmor 8.1.0 (pro), 005046, 2023-04-15T00:22:30.740738
from .pyarmor_runtime import __pyarmor__
