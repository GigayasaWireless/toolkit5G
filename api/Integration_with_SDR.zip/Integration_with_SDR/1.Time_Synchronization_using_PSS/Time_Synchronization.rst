Time/OFDM Symbol Synchronization using PSS in 5G
==================================================


.. toctree::
    :maxdepth: 4

    DL_Time(Frame)_Synchronization_using_PSS_in_5G.ipynb
    [BS-Implementation]DL_Time(Frame)_Synchronization_using_PSS_in_5G.ipynb
    [UE-Implementation]DL_Time(Frame)_Synchronization_using_PSS_in_5G.ipynb
