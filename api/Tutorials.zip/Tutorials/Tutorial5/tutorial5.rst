Detailed Tutorials on 3GPP Channel Models
=========================================

.. toctree::
    :maxdepth: 4
    
    
    1.Channel_Generation_for_Multicell_Multi_Sector_MIMO_System_for_Outdoor_Terrains.ipynb
    2.Channel_Generation_for_Multicell_Multi_Sector_MIMO_System_for_Indoor_Factory_Terrain.ipynb
    3.Channel_Generation_for_Multicell_Multi_Sector_MIMO_System_for_Indoor_Hotspot.ipynb
    4.[Mobility]Channel_Generation_for_Outdoor_Mobile_User_in_Rural_Macro_Hexagonal_Site.ipynb
    5.[Mobility2x]Channel_Generation_for_Dual_Mobility_Scenarios_in_5G_and_Beyond.ipynb
    6.Generate_UMa_Channel_for_Multiple_Frequencies.ipynb
    7.Propagation_Characteristics_of_Outdoor_Terrains.ipynb
    8.Beam_Domain and Delay_Domain_Sparsity_in_Wireless_Channel_Models.ipynb
    10.Spatially_Consistent_Channel_Modelling_for_Mobility_Simulations.ipynb
