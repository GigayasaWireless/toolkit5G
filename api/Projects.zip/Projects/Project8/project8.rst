Downlink Synchronization using SSB in 5G systems
================================================
Project-8