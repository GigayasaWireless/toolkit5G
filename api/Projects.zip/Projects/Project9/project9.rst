Uplink Synchronization using PRACH in 5G systems
================================================
Project-9