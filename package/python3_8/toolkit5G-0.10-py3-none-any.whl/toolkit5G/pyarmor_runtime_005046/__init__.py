# Pyarmor 8.1.7 (pro), 005046, 2023-07-02T13:42:32.089073
from .pyarmor_runtime import __pyarmor__
