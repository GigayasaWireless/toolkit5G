# Pyarmor 8.1.7 (pro), 005046, 2023-04-21T15:11:52.727954
from .pyarmor_runtime import __pyarmor__
